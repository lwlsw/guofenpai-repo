var iconpositions = {
	showGrid : false,
	getPositionCenter: function (element) {
        var data = element.getBoundingClientRect();
        return {
            x: data.left + data.width / 2,
            y: data.top + data.height / 2
        };
    },
    getDistanceBetweenElements: function(a, b) {
        var aPosition = this.getPositionCenter(a);
        var bPosition = this.getPositionCenter(b);
        return {
        	x: aPosition.x - bPosition.x,
        	y: aPosition.y - bPosition.y,
        	aposx: aPosition.x,
        	aposy: aPosition.y,
        	bposx: bPosition.x,
        	bposy: bPosition.y
        };
    },
	updateStorage: function(left, app){
		scaleVal = sb.getInfoFromStorage(sb.changingIcon, 'scale', '1.0');
        sb.removeDoubleLocation(sb.changingIcon);
        sb.locations.push({
            id: sb.changingIcon, 
            top: app.style.top.replace('px', ''), 
            left: left.replace('px', ''),
            opacity: app.style.opacity,
            scale: scaleVal
        });
        sb.saveInfo('sbpositions', sb.locations); 
	},
	centerIcon: function(){
		setTimeout(function(){
			jPopup({
			    type: "confirm",
			    message: "Do you want to center an icon or row?",
			    yesButtonText: "Icon",
			    noButtonText: "Row",
			    functionOnNo: function() {
			    	iconpositions.centerRow();
			    },
			    functionOnOk: function() {
			    	iconpositions.centerSingleIcon();
			    }
			});
		}, 100);
	},
	alignGrid:function(spacing, spacing2){
		var list, icon, distance, maxWidth, minWidth, top, rowsCombined, rows, unorganised,
			element, elTop, elLeft, iconFullWidth, center,
			final, firstTop, i, j, k, offset;

		list = document.getElementById('list');
		icon = document.getElementById(sb.changingIcon);
		distance = icon.getBoundingClientRect().width;
		maxWidth = (currentPage > 0) ? screen.width * (currentPage + 1) : screen.width;
		minWidth = maxWidth - screen.width;
		top = parseInt(icon.style.top, 10);
		rowsCombined = [];
		rows = [];
		unorganised = [];
		offset = 0;
		if(currentPage > 0){
			offset = screen.width * currentPage;
			console.log(offset);
		}
		getRows = function(list){
			unorganised = [];
			for (i = 0; i < list.length; i++) {
				element = list[i];
				elTop = parseInt(element.style.top, 10);
				elLeft = parseInt(element.style.left, 10);
				if(Math.abs(elTop - top) < distance && elLeft < maxWidth && elLeft > minWidth){
					rows.push({
						top: elTop,
						left: elLeft,
						id: element.id
					});
				}else{
					if(elLeft < maxWidth && elLeft > minWidth){
						unorganised.push(list[i]);
					}
				}
			}
			rowsCombined.push(rows);
			rows = [];
			if(unorganised.length > 0){
				top = parseInt(unorganised[0].style.top, 10);
				getRows(unorganised);
			}
		}

		getRows(list.children);
		iconFullWidth = distance * rowsCombined[0].length;
		center = screen.width/2 - iconFullWidth/2;
		final = center - spacing;
		if(rowsCombined[0].length > 3){
			final = center - (spacing + spacing);
		}
		if(distance != 60){
			final = final - (Math.abs(distance - 60) / 2);
		}
		if(rowsCombined[0].length % 2){

		}else{
			final = final + spacing/2;
		}
		firstTop = rowsCombined[0][0].top;
		for (j = 0; j < rowsCombined.length; j++) {
			for (var k = 0; k < rowsCombined[j].length; k++) {
				if(k === 0){
					document.getElementById(rowsCombined[j][k].id).style.left = final + offset + 'px';
					Object.keys(sb.locations).forEach(function(key) {
						if(sb.locations[key].id == rowsCombined[j][k].id){
							sb.locations[key].left = final + offset;
						}
					});
				}else{
					document.getElementById(rowsCombined[j][k].id).style.left = final + (distance*k) + (spacing*k) + offset + 'px';
					Object.keys(sb.locations).forEach(function(key) {
						if(sb.locations[key].id == rowsCombined[j][k].id){
							sb.locations[key].left = final + (distance*k) + (spacing*k) + offset;
						}
					});
				}
				if(k < rowsCombined[j][k]){
					document.getElementById(rowsCombined[j][k].id).style.top = firstTop + "px";
					Object.keys(sb.locations).forEach(function(key) {
						if(sb.locations[key].id == rowsCombined[j][k].id){
							sb.locations[key].top = firstTop;
						}
					});
				}else{
					document.getElementById(rowsCombined[j][k].id).style.top = firstTop + (distance*j) + (spacing2*j) + 'px';
					Object.keys(sb.locations).forEach(function(key) {
						if(sb.locations[key].id == rowsCombined[j][k].id){
							sb.locations[key].top = firstTop + (distance*j) + (spacing2*j);
						}
					});
				}
				
			}
		}
		iconpositions.spacingGrid();
		iconpositions.spacingGrid();
		sb.saveInfo('sbpositions', sb.locations);
		sbMenu.toggleSubMenu(document.getElementById('alignOptionsMenu'));
	},
	moveGridOnYaxis: function(offset){
		var list, icon, distance, maxWidth, minWidth, element, elTop, elLeft;
		list = document.getElementById('list');
		icon = document.getElementById(sb.changingIcon);
		distance = icon.getBoundingClientRect().width;
		maxWidth = (currentPage > 0) ? screen.width * (currentPage + 1) : screen.width;
		minWidth = maxWidth - screen.width;
		for (i = 0; i < list.children.length; i++) {
			element = list.children[i];
			elTop = parseInt(element.style.top, 10);
			elLeft = parseInt(element.style.left, 10);
			if(elLeft < maxWidth && elLeft > minWidth){
				element.style.top = (parseInt(element.style.top, 10) + offset) + 'px';
				Object.keys(sb.locations).forEach(function(key) {
					if(sb.locations[key].id == element.id){
						sb.locations[key].top = sb.locations[key].top + offset;
					}
				});
				sb.saveInfo('sbpositions', sb.locations);
			}
		}
		iconpositions.spacingGrid();
		iconpositions.spacingGrid();
		sbMenu.toggleSubMenu(document.getElementById('alignOptionsMenu'));

	},
	moveGridOnXaxis: function(offset){
		var list, icon, distance, maxWidth, minWidth, element, elTop, elLeft;
		list = document.getElementById('list');
		icon = document.getElementById(sb.changingIcon);
		distance = icon.getBoundingClientRect().width;
		maxWidth = (currentPage > 0) ? screen.width * (currentPage + 1) : screen.width;
		minWidth = maxWidth - screen.width;
		for (i = 0; i < list.children.length; i++) {
			element = list.children[i];
			elTop = parseInt(element.style.top, 10);
			elLeft = parseInt(element.style.left, 10);
			if(elLeft < maxWidth && elLeft > minWidth){
				element.style.left = (parseInt(element.style.left, 10) + offset) + 'px';
				Object.keys(sb.locations).forEach(function(key) {
					if(sb.locations[key].id == element.id){
						sb.locations[key].left = sb.locations[key].left + offset;
					}
				});
				sb.saveInfo('sbpositions', sb.locations);
			}
		}
		iconpositions.spacingGrid();
		iconpositions.spacingGrid();
		sbMenu.toggleSubMenu(document.getElementById('alignOptionsMenu'));
	},
	centerRow: function(){
		var icon, top, list, distance, array, element, elTop, i,
			final, j, firstItem, secondItem, lastItem, seperator,
			screenW, iconFullWidth, center, final, counter, screenMaxW, screenL;
		icon = document.getElementById(sb.changingIcon);
		top = parseInt(icon.style.top, 10);
		list = document.getElementById('list');
		distance = icon.getBoundingClientRect().width;
		array = [];
		//screen center
		screenW = (currentPage > 0) ? screen.width * ((currentPage + 1) + currentPage) : screen.width;
		//get the max width of the current page
		screenMaxW = (currentPage > 0) ? screen.width * (currentPage + 1) : screen.width;
		//get the left value of the current page
		screenL = screenMaxW - screen.width;
		for (i = 0; i < list.children.length; i++) {
			element = list.children[i];
			elTop = parseInt(element.style.top, 10);
			elLeft = parseInt(element.style.left, 10);
			if(Math.abs(elTop - top) < distance && elLeft < screenMaxW && elLeft > screenL){
				array.push(element);
			}
		}
		if(array.length > 0){
			firstItem = parseInt(array[0].style.left, 10);
			secondItem = parseInt(array[1].style.left, 10);
			lastItem = parseInt(array[array.length-1].style.left, 10);
			//spacing between first two icons
			seperator = (secondItem - firstItem) - distance;
			//center of all icons
			iconFullWidth = distance * array.length;
			//center of icons
			center = screenW/2 - iconFullWidth/2;

			//If more than 3 icons
			final = center - seperator;
			if(array.length > 3){
				final = center - (seperator + seperator);
			}
			//if icon has been scaled
			if(distance != 60){
				final = final - (Math.abs(distance - 60) / 2);
			}
			if(array.length % 2){
				//odd
			}else{
				//even
				final = final + seperator/2;
			}
		}
		counter = 0;
		for (j = 0; j < list.children.length; j++) {
			element = list.children[j];
			elTop = parseInt(element.style.top, 10);
			elLeft = parseInt(element.style.left, 10);
			if(Math.abs(elTop - top) < distance && elLeft < screenMaxW && elLeft > screenL){
				if(counter == 0){
					element.style.left = final + 'px';
					Object.keys(sb.locations).forEach(function(key) {
						if(sb.locations[key].id == element.id){
							sb.locations[key].left = final;
						}
					});
					sb.saveInfo('sbpositions', sb.locations);
				}else{
					element.style.left = final + (distance*counter) + (seperator*counter) + 'px';
					Object.keys(sb.locations).forEach(function(key) {
						if(sb.locations[key].id == element.id){
							sb.locations[key].left = final + (distance*counter) + (seperator*counter);
						}
					});
					sb.saveInfo('sbpositions', sb.locations);
				}
				counter++;
			}
		}
		iconpositions.spacingGrid();
		iconpositions.spacingGrid();

		jPopup({
		    type: "confirm",
		    message: "Do you wish to align top of icons?",
		    yesButtonText: "Yes",
		    noButtonText: "No",
		    functionOnNo: function() {
		    	sbMenu.toggleSubMenu(document.getElementById('alignOptionsMenu'));
		    },
		    functionOnOk: function() {
		    	iconpositions.centerIconRowTop();
		    }
		});
	},
	centerSingleIcon: function(){
		var icon = document.getElementById(sb.changingIcon),
			screenW = (currentPage > 0) ? screen.width * ((currentPage + 1) + currentPage) : screen.width,
			center = screenW/2 - icon.offsetWidth / 2 + "px";
		icon.style.left = center;
		this.updateStorage(center, icon);
	},
	getCoordsFromFirstPage: function(list){
		var list, left, right, i, element, elTop, elLeft, array;
		left = 0;
		right = screen.width;
		array = [];
		for (i = 0; i < list.children.length; i++) {
			element = list.children[i];
			elTop = parseInt(element.style.top, 10);
			elLeft = parseInt(element.style.left, 10);
			if(elLeft < right && elLeft > left){
				array.push({
					left:elLeft,
					top: elTop
				});
			}
		}
		return array;
	},
	copyFromPage: function(){
		var list, firstPage, i, j, maxWidth, minWidth, thisPageArray, newLeft, newTop,
		elLeft, element;
		//all icons on all pages
		list = document.getElementById('list');
		//get first page layout as array
		firstPage = this.getCoordsFromFirstPage(list);
		//get current page maxWidth and minWidth
		maxWidth = (currentPage > 0) ? screen.width * (currentPage + 1) : screen.width;
		minWidth = maxWidth - screen.width;
		//blank array
		thisPageArray = [];
		//get all icons on this page
		for (i = 0; i < list.children.length; i++) {
			element = list.children[i];
			elLeft = parseInt(element.style.left, 10);
			if(elLeft < maxWidth && elLeft > minWidth){
				thisPageArray.push(element.id);
			}
		}
		// if the array of the first page and array of this page are the same
		// set icons to be the same coordinates
		//if(firstPage.length === thisPageArray.length){
			for (j = 0; j < thisPageArray.length; j++) {
				//get the left value and add the screen width per page
				newLeft = firstPage[j].left + screen.width * currentPage;
				//at this time top will all be the same as pages don't scroll
				//vertically
				newTop = firstPage[j].top;
				//set icons to new positions now
				document.getElementById(thisPageArray[j]).style.left = newLeft + "px";
				document.getElementById(thisPageArray[j]).style.top = newTop + "px";
				//store new positions to use after respring
				Object.keys(sb.locations).forEach(function(key) {
					if(sb.locations[key].id == thisPageArray[j]){
						sb.locations[key].left = newLeft;
						sb.locations[key].top = newTop;
					}
				});
				sb.saveInfo('sbpositions', sb.locations);
			}
			//close the submenu
			sbMenu.toggleSubMenu(document.getElementById('alignOptionsMenu'));
		//}else{
			//not enough icons on the page
			// jPopup({
			//     type: "alert",
			//     message: "You have more apps on the first page then this page.",
			//     okButtonText: "OK"
			// });
		//}
	},
	//adds gap between icons that come (in the same row) after the icon pressed
	handleSpaceRight:function(spacing){
		var list, children, element, icon, width, elTop, top, i, offset, counter, value,
		screenMaxW, screenL, elLeft;
		if(spacing){
			list = document.getElementById('list');
			children = list.children;
			icon = document.getElementById(sb.changingIcon);
			top = parseInt(icon.style.top, 10);
			width = icon.getBoundingClientRect().width;
			distance = icon.getBoundingClientRect().width;
			referenceLeft = parseInt(icon.style.left, 10);

			//get the max width of the current page
			screenMaxW = (currentPage > 0) ? screen.width * (currentPage + 1) : screen.width;
			//get the left value of the current page
			screenL = screenMaxW - screen.width;

			counter = 0;
			for (i = 0; i < list.children.length; i++) {
				element = list.children[i];
				elTop = parseInt(element.style.top, 10);
				elLeft = parseInt(element.style.left, 10);
				if(element.id != icon.id){
					if(Math.abs(elTop - top) < distance && elLeft < screenMaxW && elLeft > screenL){ //make sure same row
						counter++;
						value = referenceLeft + (spacing *counter) + width * counter;
						list.children[i].style.left = value + "px";

						//save element position
						Object.keys(sb.locations).forEach(function(key) {
							if(sb.locations[key].id == element.id){
								sb.locations[key].left = value;
							}
						});
						sb.saveInfo('sbpositions', sb.locations);
					}
				}
			}
			iconpositions.spacingGrid();
			iconpositions.spacingGrid();
			counter = 0;
			sbMenu.toggleSubMenu(document.getElementById('alignOptionsMenu'));	
		}
	},
	spaceRight: function(){
		jPopup({
            type: "input",
            message: "Enter a number for spacing between icons.<br><br>",
            yesButtonText: "Apply",
            noButtonText: "Cancel",
            functionOnNo: function() {
                //alert('cancel');
            },
            functionOnOk: function(value) {
                iconpositions.handleSpaceRight(value);
            }
        });
	},
	//centers icons top value (of a row) to the tapped element's top value
	centerIconRowTop: function(){
		var icon, left, top, list, children, distance, element, elTop, elLeft, i;
		icon = document.getElementById(sb.changingIcon);
		left = parseInt(icon.style.left, 10);
		top = parseInt(icon.style.top, 10);
		list = document.getElementById('list');
		children = list.children;
		distance = icon.getBoundingClientRect().width;

		//get the max width of the current page
		screenMaxW = (currentPage > 0) ? screen.width * (currentPage + 1) : screen.width;
		//get the left value of the current page
		screenL = screenMaxW - screen.width;

		for (i = 0; i < list.children.length; i++) {
			element = list.children[i];
			elTop = parseInt(element.style.top, 10);
			elLeft = parseInt(element.style.left, 10);
			//if the difference between main top and other element top
			//is less than the width of the icon align tops.
			if(Math.abs(elTop - top) < distance && elLeft < screenMaxW && elLeft > screenL){
				//change element to match
				element.style.top = icon.style.top;

				//save element position
				Object.keys(sb.locations).forEach(function(key) {
					if(sb.locations[key].id == element.id){
						sb.locations[key].top = parseInt(icon.style.top, 10);
					}
				});
				sb.saveInfo('sbpositions', sb.locations);
			}
		}
		iconpositions.spacingGrid();
		iconpositions.spacingGrid();
		sbMenu.toggleSubMenu(document.getElementById('alignOptionsMenu'));
	},
	moveRowOnXaxis: function(offset){
		var icon, top, list, children, distance, element, elTop, i,
		screenMaxW, screenL, elLeft;
		icon = document.getElementById(sb.changingIcon);
		top = parseInt(icon.style.top, 10);
		list = document.getElementById('list');
		children = list.children;
		distance = icon.getBoundingClientRect().width;
		//get the max width of the current page
		screenMaxW = (currentPage > 0) ? screen.width * (currentPage + 1) : screen.width;
		//get the left value of the current page
		screenL = screenMaxW - screen.width;

		for (i = 0; i < list.children.length; i++) {
			element = list.children[i];
			elTop = parseInt(element.style.top, 10);
			elLeft = parseInt(element.style.left, 10);

			//if the difference between main top and other element top
			//is less than the width of the icon align tops.
			if(Math.abs(elTop - top) < distance && elLeft < screenMaxW && elLeft > screenL){

				//change element to match
				element.style.left = (parseInt(element.style.left, 10) + offset) + 'px';

				//save element position
				Object.keys(sb.locations).forEach(function(key) {
					if(sb.locations[key].id == element.id){
						sb.locations[key].left = sb.locations[key].left + offset;
					}
				});
				sb.saveInfo('sbpositions', sb.locations);
			}
		}
		iconpositions.spacingGrid();
		iconpositions.spacingGrid();
		sbMenu.toggleSubMenu(document.getElementById('alignOptionsMenu'));
	},
	moveRowOnYaxis: function(offset){
		var icon, top, list, children, distance, element, elTop, i,
		screenMaxW, screenL, elLeft;
		icon = document.getElementById(sb.changingIcon);
		top = parseInt(icon.style.top, 10);
		list = document.getElementById('list');
		children = list.children;
		distance = icon.getBoundingClientRect().width;
		//get the max width of the current page
		screenMaxW = (currentPage > 0) ? screen.width * (currentPage + 1) : screen.width;
		//get the left value of the current page
		screenL = screenMaxW - screen.width;

		for (i = 0; i < list.children.length; i++) {
			element = list.children[i];
			elTop = parseInt(element.style.top, 10);
			elLeft = parseInt(element.style.left, 10);

			//if the difference between main top and other element top
			//is less than the width of the icon align tops.
			if(Math.abs(elTop - top) < distance && elLeft < screenMaxW && elLeft > screenL){

				//change element to match
				element.style.top = (parseInt(element.style.top, 10) + offset) + 'px';

				//save element position
				Object.keys(sb.locations).forEach(function(key) {
					if(sb.locations[key].id == element.id){
						sb.locations[key].top = sb.locations[key].top + offset;
					}
				});
				sb.saveInfo('sbpositions', sb.locations);
			}
		}
		iconpositions.spacingGrid();
		iconpositions.spacingGrid();
		sbMenu.toggleSubMenu(document.getElementById('alignOptionsMenu'));
	},
	moveRow: function(){
		jPopup({
		    type: "confirm",
		    message: "Which axis do you want to move the row?<br>",
		    yesButtonText: "Y Axis",
		    noButtonText: "X Axis",
		    functionOnNo: function() {
		        jPopup({
		            type: "input",
		            message: "Enter a number to move row. Use negative value to move left.<br><br>",
		            yesButtonText: "Apply",
		            noButtonText: "Cancel",
		            functionOnNo: function() {
		                //alert('cancel');
		            },
		            functionOnOk: function(value) {
		            		iconpositions.moveRowOnXaxis(Number(value));
		            }
		        });
		    },
		    functionOnOk: function() {
		        jPopup({
		            type: "input",
		            message: "Enter a number to move row. Use negative value to move up.<br><br>",
		            yesButtonText: "Apply",
		            noButtonText: "Cancel",
		            functionOnNo: function() {
		                //alert('cancel');
		            },
		            functionOnOk: function(value) {
		            		iconpositions.moveRowOnYaxis(Number(value));
		            }
		        });
		    }
		});
	},
	resetLocation: function(divID){
		Object.keys(sb.locations).forEach(function(key) {
			if(sb.locations[key].id == divID){
				sb.locations[key].top = 40;
				sb.locations[key].left = 40;
			}
		});
		sb.saveInfo('sbpositions', sb.locations);
		document.getElementById(divID).style.left = "40px";
		document.getElementById(divID).style.top = "40px";
		document.getElementById('resetIconPositions').style.display = "none";
		document.getElementById('iconOptionsMenu').style.display = "none";
	},
	closeReset: function(){
		document.getElementById('resetIconPositions').style.display = "none";
		document.getElementById('iconOptionsMenu').style.display = "none";
	},
	resetIconPosition: function(){
		var holder = document.getElementById('resetIconPositions');
			holder.style.display = "block";
			holder.innerHTML = "<li class='resetIconLI' onclick='iconpositions.closeReset()'>Close Menu</li>";
			Object.keys(sb.locations).forEach(function(key) {
			  var div = document.createElement('li');
			  	  div.style.width = "100%";
			  	  div.className = "resetIconLI";
			  	  div.title =  sb.locations[key].id;
			  	  div.onclick = function(){
			  	  	iconpositions.resetLocation(this.title);
			  	  };
			  	  div.innerHTML = sb.locations[key].id + " X:" + sb.locations[key].left + " Y:" + sb.locations[key].top;
			  	  holder.appendChild(div);
			});
	},
	spacingGrid: function(codeCalled){
		var list = document.getElementById('list'),
			gridHolder = document.getElementById('customGrid'),
			listIcons = list.children,
			iconWidth;
			gridHolder.innerHTML = "";
			if(!codeCalled){
				if(this.showGrid){
					this.showGrid = false;
					return;
				}
				this.showGrid = true;
			}
			for (var i = 0; i < list.children.length; i++) {
				if(list.children[i].classList.contains('iconView')){ //only icons not widgets
					var div = document.createElement('div');
						div.style.position = "absolute";
						div.style.left = list.children[i].style.left;
						div.style.top = list.children[i].style.top;
						div.style.marginTop = "-20px";
						div.style.padding = "2px";
						div.style.paddingLeft = "4px";
						div.style.paddingRight = "4px";
						div.style.borderRadius = "99px";
						div.style.backgroundColor = 'black';
						div.style.fontSize = "10px";
						div.innerHTML = "Y:" + list.children[i].style.top.replace('px','') + " X:" + list.children[i].style.left.replace('px',''); 
						div.style.whiteSpace = 'nowrap'; 
						iconWidth = list.children[i].getBoundingClientRect().width;
						gridHolder.appendChild(div);
				}


				//space between icons left/right
				var leftVal = null;
				var centerVal = null;
				var topVal = null;
				var centerTopVal = null;
				for (var e = 0; e < list.children.length; e++) {
					if(list.children[e].classList.contains('iconView')){
						var L1 = parseInt(list.children[i].style.left, 10);
						var L2 = parseInt(list.children[e].style.left, 10);
						var T1 = parseInt(list.children[i].style.top, 10);
						var T2 = parseInt(list.children[e].style.top, 10);
						if(L2 > L1){
							if(!leftVal && T1 == T2){
								leftVal = L2;
								centerVal = L2 - L1;
							}else{
								if(L2 < leftVal && T1 == T2){
									leftVal = L2;
									centerVal = L2 - L1;
								}
							}
						}
					}
				}

				//space between icons top/bottom
				for (var f = 0; f < list.children.length; f++) {
					if(list.children[f].classList.contains('iconView')){
						var Le1 = parseInt(list.children[i].style.left, 10);
						var Le2 = parseInt(list.children[f].style.left, 10);
						var Te1 = parseInt(list.children[i].style.top, 10);
						var Te2 = parseInt(list.children[f].style.top, 10);
						if(Te2 > Te1){
							if(!topVal && Le1 == Le2){
								topVal = Te2;
								centerTopVal = Te2 - Te1;
							}else{
								if(Te2 < topVal && Le1 == Le2){
									topVal = Te2;
									centerTopVal = Te2 - Te1;
								}
							}
						}
					}
				}
				//center of x axis
				if(centerVal){
					centerVal = centerVal - iconWidth;
					var centerDiv = document.createElement('div');
						centerDiv.style.position = "absolute";
						centerDiv.className = 'spacingNumber';
						centerDiv.style.left = list.children[i].style.left;
						centerDiv.style.top = list.children[i].style.top;
						centerDiv.style.marginTop = "20px";
						centerDiv.style.marginLeft = 50 + "px";
						centerDiv.style.borderRadius = "2px";
						centerDiv.style.backgroundColor = 'red';
						centerDiv.style.fontSize = "10px";
						centerDiv.style.padding = "2px";
						centerDiv.style.paddingLeft = "4px";
						centerDiv.style.paddingRight = "4px";
						centerDiv.innerHTML = centerVal;
						gridHolder.appendChild(centerDiv);
				}
				//center of y axis
				if(centerTopVal){
					centerTopVal = centerTopVal - iconWidth;
					var centerDiv2 = document.createElement('div');
						centerDiv2.style.position = "absolute";
						centerDiv2.className = 'spacingNumber';
						centerDiv2.style.left = list.children[i].style.left;
						centerDiv2.style.top = list.children[i].style.top;
						centerDiv2.style.marginTop = 50 + "px";
						centerDiv2.style.marginLeft = "20px";
						centerDiv2.style.borderRadius = "2px";
						centerDiv2.style.backgroundColor = 'red';
						centerDiv2.style.fontSize = "10px";
						// centerDiv2.style.padding = "2px";
						centerDiv2.style.paddingLeft = "4px";
						centerDiv2.style.paddingRight = "4px";
						centerDiv2.innerHTML = centerTopVal;
						gridHolder.appendChild(centerDiv2);
				}
			}
	},
};





