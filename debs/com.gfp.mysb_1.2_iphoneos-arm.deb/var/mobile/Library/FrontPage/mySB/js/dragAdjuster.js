/* 
	Draggable object that moves the badge.
*/

(function(window, doc) {
    var closeButton = null,
        dragElement,
        windowDiv,
        settings;
    function addDraggable(dragDiv, windowDiv){
        $(dragDiv).draggable({
            stop: function (ev, ui) {
                settings.stop(ev, ui);
            },
            drag: function (ev, ui) {
                settings.drag(ev, ui);
            }
        });
    }
    function closeDragAdjuster(){
        $(dragElement).draggable( "destroy" );
        closeButton.removeEventListener('click', closeDragAdjuster, false);
        doc.body.removeChild(windowDiv);
    }
    function createCloseButton(){
        closeButton = document.createElement('div');
        closeButton.innerHTML = "X";
        closeButton.style.cssText = "position:absolute;top:0;right:0;width:30px;height:30px;line-height:30px;border-radius:99px;text-align:center;heigh:30px;background-color:red;";
        closeButton.addEventListener('click', closeDragAdjuster, false);
        return closeButton;
    }
    function createDragger(){
            windowDiv = doc.createElement('div');
            windowDiv.style.cssText = "position:absolute;display:block;text-align:center;left:50%;top:50%;-webkit-transform:translate(-50%, -50%);height:300px;width:300px;background-color:transparent;z-index:99999;";
            dragElement = doc.createElement('div');
            dragElement.style.cssText = "position:relative;width:80px;height:40px;line-height:40px;background-color:"+settings.color+";margin-left:110px;margin-top:130px;";
            dragElement.innerHTML = "Drag Me";
            addDraggable(dragElement, windowDiv);
            windowDiv.appendChild(dragElement);
            windowDiv.appendChild(createCloseButton());
            doc.body.appendChild(windowDiv);
    }
    function initExternalMethods() {
        var externalMethods = {};
        externalMethods.init = function(obj) {
			if(obj){
                settings = obj;
                createDragger();
			}
		};
        return externalMethods;
    }
    window.dragAdjuster = initExternalMethods();
}(window, document));


// setTimeout(function(){
//     (function(){
//         var scale = "1.0",
//             xInput = document.getElementById('badgeXaxisInput'),
//             yInput = document.getElementById('badgeYaxisInput'),
//             elements = document.querySelectorAll(".iconImageBadge");
//             function updateElements(left, top){
//                 for(var i = 0; i < elements.length; i++){
//                     if(localStorage.sizebadgeoptions){
//                         scale = localStorage.sizebadgeoptions.split('~')[2];
//                     }
//                     elements[i].style.webkitTransform = "scale(" + scale + ")translate("+left+"px, "+top+"px)";
//                 }  
//                 xInput.value = left;
//                 yInput.value = top;
//             }
//         dragAdjuster.init({
//             color:"blue",
//             drag: function(ev, ui){
//                 ui.position.left = Math.round(ui.position.left);
//                 ui.position.top = Math.round(ui.position.top);
//                 updateElements(ui.position.left, ui.position.top);
//             },
//             stop:function(ev, ui){
//                 ui.position.left = Math.round(ui.position.left);
//                 ui.position.top = Math.round(ui.position.top);
//                 var x, y, scale, store;
//                 x = ui.position.left;
//                 y = ui.position.top;
//                 if(localStorage.sizebadgeoptions){
//                     scale = localStorage.sizebadgeoptions.split('~')[2];
//                 }
//                 if(!x){
//                     x = 0;
//                 }
//                 if(!y){
//                     y = 0;
//                 }
//                 if(!scale){
//                     scale = 1.0;
//                 }
//                 store = x + "~" + y + "~" + scale;
//                 localStorage.sizebadgeoptions = store;
//                 sbMenu.addRule(document.styleSheets[0], ".iconImageBadge", "-webkit-transform:scale(" + scale + ")translate(" + x + "px," + y + "px);!important");
//             }
//         });
//     }());
// },1000);