function createGrid(sizeleft, sizetop) {
    var i,
        sel = $('.grids'),
        height = sel.height(),
        width = sel.width(),
        ratioW = Math.floor(width / sizeleft),
        ratioH = Math.floor(height / sizetop);

    for (i = 0; i <= ratioW; i++) { // vertical grid lines
        $('<div />').css({
                'top': 0,
                'left': i * sizetop - 1,
                'width': 2,
                'height': height
            })
            .addClass('gridlines')
            .appendTo(sel);
    }

    for (i = 0; i <= ratioH; i++) { // horizontal grid lines
        $('<div />').css({
                'top': i * sizeleft - 1,
                'left': 0,
                'width': width,
                'height': 2
            })
            .addClass('gridlines')
            .appendTo(sel);
    }

    $('.gridlines').show();
}
createGrid(17, 17);