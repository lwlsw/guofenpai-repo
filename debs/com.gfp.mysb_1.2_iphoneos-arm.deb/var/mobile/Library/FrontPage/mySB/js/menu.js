/*global alert, console, FPI, locked, $*/
"use strict";
var sbMenu = {
    menu: document.getElementById('menu'),
    labelsHidden: false,
    badgesHidden: false,
    menuOpen: false,
    addRule: function (sheet, selector, styles) {
        if (sheet.insertRule) {
            return sheet.insertRule(selector + " {" + styles + "}", sheet.cssRules.length);
        }
        if (sheet.addRule) {
            return sheet.addRule(selector, styles);
        }
    },
    removeRule: function (sheet, selector, styles){
        var she, e, st;
        if(sheet.cssRules){
            for (she = 0; she < sheet.cssRules.length; she++) {
                if (sheet.cssRules[she].selectorText == selector) { 
                    //battery border is a special fuck
                    if(selector == "#battery"){
                        for (e = 0; e < sheet.cssRules[she].style.length; e++) {
                            st = sheet.cssRules[she].style[e];
                            if(st === "border-top-color"){
                                sheet.deleteRule(she);   
                            }
                        }
                    }
                    //all other css values
                    if(sheet.cssRules[she].style[0] == styles){
                        sheet.deleteRule(she);
                    }
                }
            }
        }
    },
    changeWifiAmount:function(amount){
        sbMenu.addRule(document.styleSheets[0], ".wifibg, .wifibg:before", "-webkit-clip-path: circle(" + amount + "px at center)!important");
    },
    changeSignalAmount: function (amount){
        sbMenu.addRule(document.styleSheets[0], ".topSignal", "-webkit-clip-path: inset(0% " + amount + "% 0% 0%)!important");
    },
    animateIn: function(div){
        div.style.opacity = 0;
        div.style.webkitTransform = "translate(-50%, -50%)scale(0.5)";
        div.style.visibility = "none";
        div.style.display = "block";
        setTimeout(function(){
            div.style.visibility = "visible";
            div.style.opacity = 1;
            div.style.webkitTransform = "translate(-50%, -50%)scale(1)";
        }, 0);
    },
    animateOut: function(div){
        div.style.opacity = 0;
        div.style.webkitTransform = "translate(-50%, -50%)scale(0.5)";
        setTimeout(function(){
            div.style.display = "none";
        }, 500);
    },
    toggleSubMenu: function(menu){
        if (menu.style.display === "none") {
            menu.style.display = "block";
            window.location = 'frontpage:stopTouchPass';
            //this.animateIn(menu);
        } else {
            //this.animateOut(menu);
            menu.style.display = "none";
            window.location = 'frontpage:allowTouchPass';
        }
    },
    toggleMenu: function () {
        if (this.menu.style.display === "none") {
            this.animateIn(this.menu);
            sbMenu.menuOpen = true;
            window.location = 'frontpage:allowTouchPass';
        } else {
            this.animateOut(this.menu);
            sbMenu.menuOpen = false;
            window.location = 'frontpage:stopTouchPass';
        }
    },
    hideLabels: function () {
        var div = document.getElementById('hideLabels');
        if (sbMenu.labelsHidden) {
            div.innerHTML = "Hide Labels";
            sbMenu.labelsHidden = false;
            sbMenu.addRule(document.styleSheets[0], ".iconImageLabel", "opacity:1");
            localStorage.removeItem('sbhidelabels');
        } else {
            div.innerHTML = "Show Labels";
            sbMenu.labelsHidden = true;
            sbMenu.addRule(document.styleSheets[0], ".iconImageLabel", "opacity:0");
            localStorage.sbhidelabels = "YES";
        }
    },
    hideBadges: function () {
        var div = document.getElementById('hideBadges');
        if (sbMenu.badgesHidden) {
            div.innerHTML = "Hide Badges";
            sbMenu.badgesHidden = false;
            sbMenu.addRule(document.styleSheets[0], ".iconImageBadge", "opacity:1");
            localStorage.removeItem('sbhidebadges');
        } else {
            div.innerHTML = "Show Badges";
            sbMenu.badgesHidden = true;
            sbMenu.addRule(document.styleSheets[0], ".iconImageBadge", "opacity:0");
            localStorage.sbhidebadges = "YES";
        }
    },
    disableSnapping: function () {
        var div = document.getElementById('disableSnapping');
        if (localStorage.sbnosnap) {
            localStorage.removeItem('sbnosnap');
            div.innerHTML = "Enable Snapping";
        } else {
            localStorage.sbnosnap = "YES";
            div.innerHTML = "Disable Snapping";
        }
        //location.reload(true);
    },
    toggleLock: function () {
        var div = document.getElementById('lockEverything');
        if (localStorage.sblock) {
            localStorage.removeItem('sblock');
            document.getElementById('list').classList.remove('canceledIcons');
            div.innerHTML = "Lock Items";
            widgets.setWidgetDisableMove("remove");
        } else {
            document.getElementById('list').classList.add('canceledIcons');
            localStorage.sblock = "YES";
            div.innerHTML = "Unlock Items";
            widgets.setWidgetDisableMove("add");
        }
    },
    togglePageLock: function () {
        var div = document.getElementById('lockPaging');
        if (localStorage.sblockpaging) {
            localStorage.removeItem('sblockpaging');
            div.innerHTML = "Lock Paging";
            document.getElementById('container').classList.remove('canceled');
            lockpages = false;
        } else {
            localStorage.sblockpaging = "YES";
            div.innerHTML = "Unlock Paging";
            document.getElementById('container').classList.add('canceled');
            lockpages = true;
        }
        //location.reload(true);
    },
    setIconSize: function (value) {
        sbMenu.addRule(document.styleSheets[0], ".iconImageView", "width:" + value + "px!important");
        sbMenu.addRule(document.styleSheets[0], ".iconView", "width:" + value + "px!important");
        sbMenu.addRule(document.styleSheets[0], ".iconImageView", "height:" + value + "px!important");
        sbMenu.addRule(document.styleSheets[0], ".iconView", "height:" + value + "px!important");
        sbMenu.addRule(document.styleSheets[0], ".iconImageLabel", "width:" + value + "px!important");
        sbMenu.addRule(document.styleSheets[0], ".iconViewDragging:before", "margin-top:" + value + "px!important");
		var v = Number(value) / 10;
		sbMenu.addRule(document.styleSheets[0], ".iconImageBadge", "height:" + v + "px!important;");
		sbMenu.addRule(document.styleSheets[0], ".iconImageBadge", "line-height:" + v + "px!important;");
		sbMenu.addRule(document.styleSheets[0], ".iconImageBadge", "padding:" + v + "px!important;");
		sbMenu.addRule(document.styleSheets[0], ".iconImageBadge", "font-size:" + v * 2 + "px!important;");

    },
    setBadgeColor: function (value) {
        sbMenu.addRule(document.styleSheets[0], ".iconImageBadge", "background-color:" + value + "!important");
    },
    setBadgeBorderColor: function (value) {
        sbMenu.addRule(document.styleSheets[0], ".iconImageBadge", "border: 1px solid " + value + "!important");
    },
    setBadgeTextColor: function (value) {
        sbMenu.addRule(document.styleSheets[0], ".iconImageBadge", "color: " + value + "!important");
    },
    setIconRadius: function(radius){
        sbMenu.addRule(document.styleSheets[0], ".iconImageView", "border-radius:" + radius + "px");
    },
    setLabelColor: function (val) {
        sbMenu.addRule(document.styleSheets[0], ".iconImageLabel", "color:" + val + "!important;");
    }
};
