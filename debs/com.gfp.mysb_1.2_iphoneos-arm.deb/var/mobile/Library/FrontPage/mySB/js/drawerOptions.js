var drawerOptions = {
	init: function(){
		if(localStorage.drawerBGColor){
			sbMenu.addRule(document.styleSheets[0], ".drawer_main", "background-color: " + localStorage.drawerBGColor + "!important;");
		}
		if(localStorage.drawerBadgeColor){
			sbMenu.addRule(document.styleSheets[0], ".drawer_icon::before", "background-color: " + localStorage.drawerBadgeColor + "!important;");
		}
		if(localStorage.drawerTextColor){
			sbMenu.addRule(document.styleSheets[0], ".drawer_icon::before", "color: " + localStorage.drawerTextColor + "!important;");
		}
		if(localStorage.drawerLabelColor){
			sbMenu.addRule(document.styleSheets[0], ".drawer_icon::after", "color: " + localStorage.drawerLabelColor + "!important;");
		}
		if(localStorage.drawerIconRoundnessColor){
			sbMenu.addRule(document.styleSheets[0], ".drawer_icon", "border-radius: " + localStorage.drawerIconRoundnessColor + "px!important;");
			sbMenu.addRule(document.styleSheets[0], ".drawerFolderIcon", "border-radius: " + localStorage.drawerIconRoundnessColor + "px!important;");
		}
		if(localStorage.drawershortcutTextColor){
			sbMenu.addRule(document.styleSheets[0], ".shortcut", "color: " + localStorage.drawershortcutTextColor + "!important;");
		    sbMenu.addRule(document.styleSheets[0], ".drawerFolderIcon::after", "color: " + localStorage.drawershortcutTextColor + "!important;");
		}
		if(localStorage.drawershortcutBGColor){
			sbMenu.addRule(document.styleSheets[0], ".shortcutFolderHolder", "background-color: " + localStorage.drawershortcutBGColor + "!important;");
		    sbMenu.addRule(document.styleSheets[0], ".shortcutHolder", "background-color: " + localStorage.drawershortcutBGColor + "!important;");
		}
		if(localStorage.drawericonopacity){
			// if(localStorage.drawericonopacity == 0){
			// 	sbMenu.addRule(document.styleSheets[0], ".drawer_main", "-webkit-backdrop-filter:blur(0)!important;");
			// }
			sbMenu.addRule(document.styleSheets[0], ".drawer_icon", "opacity: " + localStorage.drawericonopacity + "!important;");
		}
	},
	changeOption:function(option, value){
		switch(option) {
		  case 'backgroundcolor':
		    sbMenu.addRule(document.styleSheets[0], ".drawer_main", "background-color: " + value + "!important;");
		    localStorage.drawerBGColor = value;
		    break;
		  case 'badgecolor':
		    sbMenu.addRule(document.styleSheets[0], ".drawer_icon::before", "background-color: " + value + "!important;");
		    localStorage.drawerBadgeColor = value;
		    break;
		  case 'badgetextcolor':
		    sbMenu.addRule(document.styleSheets[0], ".drawer_icon::before", "color: " + value + "!important;");
		    localStorage.drawerTextColor = value;
		    break;
		  case 'labelcolor':
		    sbMenu.addRule(document.styleSheets[0], ".drawer_icon::after", "color: " + value + "!important;");
		    localStorage.drawerLabelColor = value;
		    break;
		  case 'iconroundness':
		    sbMenu.addRule(document.styleSheets[0], ".drawer_icon", "border-radius: " + value + "px!important;");
		    sbMenu.addRule(document.styleSheets[0], ".drawerFolderIcon", "border-radius: " + value + "px!important;");
		    localStorage.drawerIconRoundnessColor = value;
		    break;
		  case 'shortcuttext':
		    sbMenu.addRule(document.styleSheets[0], ".shortcut", "color: " + value + "!important;");
		    sbMenu.addRule(document.styleSheets[0], ".drawerFolderIcon::after", "color: " + value + "!important;");
		    localStorage.drawershortcutTextColor = value;
		    break;
		  case 'shortcutbg':
		    sbMenu.addRule(document.styleSheets[0], ".shortcutFolderHolder", "background-color: " + value + "!important;");
		    sbMenu.addRule(document.styleSheets[0], ".shortcutHolder", "background-color: " + value + "!important;");
		    localStorage.drawershortcutBGColor = value;
		    break;
		  case 'iconopacity':
		    sbMenu.addRule(document.styleSheets[0], ".drawer_icon", "opacity: " + value + "!important;");
		    localStorage.drawericonopacity = value;
		 //    if(value == 0){
			// 	sbMenu.addRule(document.styleSheets[0], ".drawer_main", "-webkit-backdrop-filter:blur(0)!important;");
			// }
		    break;
		}
	},
	clearOptions: function(){
		localStorage.removeItem('drawerBGColor');
		localStorage.removeItem('drawerBadgeColor');
		localStorage.removeItem('drawerTextColor');
		localStorage.removeItem('drawerLabelColor');
		localStorage.removeItem('drawerIconRoundnessColor');
		localStorage.removeItem('drawershortcutTextColor');
		localStorage.removeItem('drawershortcutBGColor');
		localStorage.removeItem('drawericonopacity');

		sbMenu.removeRule(document.styleSheets[0], ".drawer_main", "background-color");
		sbMenu.removeRule(document.styleSheets[0], ".drawer_icon::before", "background-color");
		sbMenu.removeRule(document.styleSheets[0], ".drawer_icon::before", "color");
		sbMenu.removeRule(document.styleSheets[0], ".drawer_icon::after", "color");
		sbMenu.removeRule(document.styleSheets[0], ".drawer_icon", "border-radius");

		sbMenu.removeRule(document.styleSheets[0], ".shortcut", "color");
		sbMenu.removeRule(document.styleSheets[0], ".drawerFolderIcon::after", "color");

		sbMenu.removeRule(document.styleSheets[0], ".shortcutFolderHolder", "background-color");
		sbMenu.removeRule(document.styleSheets[0], ".shortcutHolder", "background-color");
		sbMenu.removeRule(document.styleSheets[0], ".drawer_icon", "opacity");
		//sbMenu.removeRule(document.styleSheets[0], ".drawer_main", "-webkit-backdrop-filter");

		jPopup({
            type: "alert",
            message: "Drawer options reset to default. You may need to respring to see changes.",
            okButtonText: "OK"
        });
	}
};