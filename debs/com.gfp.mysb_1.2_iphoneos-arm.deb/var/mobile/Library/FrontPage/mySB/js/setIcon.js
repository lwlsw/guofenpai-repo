

/*global alert, console, FPI, $*/
"use strict";
var sb = {
    dragging : false,
    list : document.getElementById('list'),
    locations : [],
    iconInfo : [],
    deleteBundle: false,
    changingIcon: "",
    changingApp: false,
    changedIcons: {},
    removeWidget: function (){
        widgets.removeWidgetFromSB(widgets.editingWidget);
        document.getElementById('widgetEditMenu').style.display = 'none';
    },
    removeDoubleLocation: function (div) {
        var i;
        for (i = 0; i < sb.locations.length; i += 1) {
            if (sb.locations[i].id === div) {
                sb.locations.splice(i, 1);
            }
        }
    },
    saveInfo: function (name, info) {
        localStorage.setItem(name, JSON.stringify(info));
    },
    saveCurrent: function () {
        localStorage.setItem('sbpositions', JSON.stringify(sb.locations));
        localStorage.setItem('sbiconInfo', JSON.stringify(sb.iconInfo));

        if(sb.changedIcons){
            localStorage.setItem('sbchangedicons', JSON.stringify(sb.changedIcons));
        }
    },
    createDOM : function (params) {
        var d = document.createElement(params.type);
        if (params.className) {
            d.setAttribute('class', params.className);
        }
        if (params.id) {
            d.id = params.id;
        }
        if (params.innerHTML) {
            d.innerHTML = params.innerHTML;
        }
        if (params.attribute) {
            d.setAttribute(params.attribute[0], params.attribute[1]);
        }
        return d;
    },
    makeDraggable: function (icon) {
        var iconSize = 60,
            gridSnap = [1, 1];
        if (localStorage.sbnosnap) {
            gridSnap = [1, 1];
        }
        $(icon).draggable({
            grid: gridSnap,
            cancel: ".canceledIcons",
            containment : [0, 0, screen.width - iconSize, screen.height - iconSize],
            //disabled: locked,
            stop: function (ev, ui) {
                setTimeout(function () {
                    sb.dragging = false;
                }, 1000);
                var tops = ui.position.top,
                    lefts = ui.position.left,
                    divid = this.id,
                    scaleVal = sb.getInfoFromStorage(divid, 'scale', '1.0'),
                    opacityVal = sb.getInfoFromStorage(divid, 'opacity', '1.0');
                sb.removeDoubleLocation(divid);
                sb.locations.push({
                    id: divid, 
                    top: tops, 
                    left: lefts,
                    opacity: opacityVal,
                    scale: scaleVal
                });
                sb.saveInfo('sbpositions', sb.locations);
                document.getElementById(this.id).classList.remove("iconViewDragging");
                document.getElementById(this.id).classList.remove("iconViewDraggingVert");
                if(iconpositions.showGrid){
                    iconpositions.spacingGrid(true);
                }
            },
            drag: function (ev, ui) {
                ui.position.left = Math.round(ui.position.left);
                ui.position.top = Math.round(ui.position.top);
                document.getElementById(this.id).classList.add("iconViewDragging");
                document.getElementById(this.id).classList.add("iconViewDraggingVert");
                sb.dragging = true;
            }
        });
    },
    checkIfExists: function (imageUrl, callBack) {
        var imageData = new Image();
        imageData.onload = function () {
            callBack(true);
        };
        imageData.onerror = function () {
            var imageSecond = new Image(),
                split,
                bundle,
                url;
                imageSecond.onload = function(){
                    callBack(true, url)
                };
                imageSecond.onerror = function(){
                    if(imageUrl.includes('drawer') || imageUrl.includes('folder')){
                        if(imageUrl.includes('drawer')){
                            callBack(true, "drawer.png");
                        }
                        if(imageUrl.includes('folder')){
                            callBack(true, "addApp.png");
                        }
                    }else{
                        callBack(false);
                    }
                };
                split = imageUrl.split('/');
                bundle = split[split.length - 1];
                bundle = bundle.split('-')[0];
                url = '/var/mobile/Library/FrontPageCache/' + bundle + '.png';
                imageSecond.src = url;
        };
        imageData.src = imageUrl;
    },
    replaceIcon: function (id, bundle, name, iconImage, num) {
        var icon = sb.createDOM({
                type: 'li',
                id: id,
                className: 'iconView',
                attribute: ['data-id', "icon_" + num]
            }),
            div = sb.createDOM({
                type: 'div',
                className: 'iconHolder'
            }),
            image = sb.createDOM({
                type: 'div',
                className: 'iconImageView'
            }),
            label = sb.createDOM({
                type: 'div',
                className: 'iconImageLabel',
                innerHTML: name
            }),
            badge = sb.createDOM({
                type: 'div',
                className: 'iconImageBadge'
            }),
            imageLoc,
            imageUrl,
            bare;
        
        imageLoc = iconImage;
        if(bundle === "com.junesiphone.drawer"){
            imageLoc = 'url("drawer.png")';
        }
        if(sb.changedIcons[bundle]){
            imageLoc = sb.changedIcons[bundle].url;
        }

        bare = imageLoc.replace('url("', '');
        bare = bare.replace('")', '');

        this.checkIfExists(bare, function(existsImage, url) {
            if(url){
                image.style.backgroundImage = "url('" + url + "')";
            }else{
                if(existsImage == true) {
                    image.style.backgroundImage = imageLoc;
                }else {
                    image.style.backgroundImage = "url('addApp.png')";
                }
            }
        }); 

        if(bundle == "com.junesiphone.drawer"){
            badge.innerHTML = "";
        }else if (FPI.bundle[bundle]) {
            if(FPI.bundle[bundle].badge > 0){
                badge.innerHTML = FPI.bundle[bundle].badge;
            }else{
                badge.innerHTML = "";
            }
        }else{
            badge.innerHTML = "";
        }

        div.appendChild(image);
        div.appendChild(label);
        div.appendChild(badge);
        icon.appendChild(div);
        sb.list.appendChild(icon);
        sb.makeDraggable(icon);
    },
    stickToIcon: function(){
        folders.stickToIcon();
    },
    setIcon: function (bundle) {
        // alert(bundle);
        if(document.getElementById(bundle)){
            jPopup({
                type: "alert",
                message: "App is already placed somewhere.",
                okButtonText: "OK"
            });
            //show user icon if hidden
            document.getElementById(bundle).style.opacity = "1";
            setTimeout(function(){
                document.getElementById(bundle).style.opacity = sb.getInfoFromStorage(bundle, 'opacity', '1.0');
            }, 5000);
            return;
        }
        var icon = document.createElement('li'),
            div = document.createElement('div'),
            label = document.createElement('div'),
            image = document.createElement('div'),
            badge = document.createElement('div'),
            childId = document.getElementById('list').children.length,
            imageLoc,
            container,
            leftM,
            name;
        icon.className = 'iconView';
        icon.id = bundle;
        leftM = new WebKitCSSMatrix(document.getElementById('container').style.webkitTransform);
        icon.style.left = Math.abs(parseInt(leftM.m41, 10)) + "px";

        //container = document.getElementById('container').style.left;
        //icon.style.left = Math.abs(parseInt(container, 10)) + "px";

        if(bundle == "com.junesiphone.drawer"){
            badge.innerHTML = "";
            name = "App Drawer";
        }else if (bundle.indexOf('folder') !== -1){ ///FOLDER
            badge.innerHTML = "";
            name = bundle.replace('folder', '');
            //icon.setAttribute('data-folder', 'isFolder');
        }else{
            if(FPI.bundle[bundle].badge > 0){
                badge.innerHTML = FPI.bundle[bundle].badge;
            }else{
                badge.innerHTML = "";
            }
            name = FPI.bundle[bundle].name;
        }
        icon.setAttribute('data-id', "icon_" + Number(childId) + 1);
        icon.style.top = "100px";
        div.className = "iconHolder";
        image.className = "iconImageView";
        label.className = "iconImageLabel";
        badge.className = "iconImageBadge";
        label.innerHTML = name;

        imageLoc = 'url("/var/mobile/Library/FrontPageCache/' + bundle + '.png")';

        if(bundle === "com.junesiphone.drawer"){
            imageLoc = 'url("drawer.png")';
        }else if (bundle.indexOf('folder') !== -1){ //FOLDER
            imageLoc = 'url("addApp.png")';
        }

        if(sb.changedIcons[bundle]){
            imageLoc = sb.changedIcons[bundle].url;
        }
        image.style.backgroundImage = imageLoc;

        div.appendChild(image);
        div.appendChild(label);
        div.appendChild(badge);
        icon.appendChild(div);
        sb.list.appendChild(icon);
        sb.makeDraggable(icon);
        sb.iconInfo.push({id: icon.id, bundle: bundle, name: name, iconImage: 'url("/var/mobile/Library/FrontPageCache/' + bundle + '.png")'});
        this.saveInfo('sbiconInfo', sb.iconInfo);
    },
    setIconImage: function (img) {
        var bgImage = 'url("' + img + '")';
        document.getElementById(sb.changingIcon).children[0].children[0].style.backgroundImage = bgImage;
        sb.changedIcons[sb.changingIcon] = {
            url: bgImage
        };
        localStorage.sbchangedicons = JSON.stringify(sb.changedIcons);
    },
    changeDrawerIconWindow: function () {
        window.location = 'frontpage:isInTerminal';
        document.getElementById('drawerIconMenu').style.display = 'block';
    },
    changeIconWindow: function () {
        sb.dragging = true;
        window.location = 'frontpage:isInTerminal';
        document.getElementById('drawerIconMenu').style.display = 'block';
    },
    removeIconSB: function(){
        sb.dragging = false;
        window.location = 'frontpage:isntInTerminal';
        sb.removeIconFromSB(sb.changingIcon);
        document.getElementById('drawerIconMenu').style.display = 'none'
    },
    resetIconImage: function(){
        delete sb.changedIcons[sb.changingIcon];
        sb.saveCurrent();
        sb.reload();
        //location.reload(true);
    },
    centerIcon: function(){
        iconpositions.centerIcon();
    },
    centerRowTop: function(){
        iconpositions.centerIconRowTop();
    },
    spaceRight:function(){
        iconpositions.spaceRight();
    },
    moveRow: function(){
        iconpositions.moveRow();
    },
    moveGrid:function(){
        document.getElementById('alignOptionsMenu').style.display = 'none';
        function getCssProperty(elem, property){
            return window.getComputedStyle(elem,null).getPropertyValue(property);
         }
        dragAdjuster.init({
            color:"black",
            drag: function(ev, ui){
                var list = document.getElementById('list'),
                    element;
                ui.position.left = Math.round(ui.position.left);
                ui.position.top = Math.round(ui.position.top);
                for (i = 0; i < list.children.length; i++) {
                    element = list.children[i];
                    element.style.marginTop = ui.position.top + 'px';
                    element.style.marginLeft = ui.position.left + 'px';
                }
            },
            stop:function(ev, ui){
                var list = document.getElementById('list'),
                    element, offsetTop, offsetLeft;
                ui.position.left = Math.round(ui.position.left);
                ui.position.top = Math.round(ui.position.top);
                for (i = 0; i < list.children.length; i++) {
                    element = list.children[i];
                    offsetTop = parseInt(element.style.marginTop, 10);
                    offsetLeft = parseInt(element.style.marginLeft, 10);
                    Object.keys(sb.locations).forEach(function(key) {
                        if(sb.locations[key].id == element.id){
                            sb.locations[key].top = sb.locations[key].top + offsetTop;
                            sb.locations[key].left = sb.locations[key].left + offsetLeft;
                        }
                        sb.saveInfo('sbpositions', sb.locations);
                    });
                }
            }
        });
        

        // jPopup({
        //     type: "confirm",
        //     message: "Which axis do you want to move the entire icon grid?<br>",
        //     yesButtonText: "Y Axis",
        //     noButtonText: "X Axis",
        //     functionOnNo: function() {
        //         jPopup({
        //             type: "input",
        //             message: "Enter a number to move row. Use negative value to move left.<br><br>",
        //             yesButtonText: "Apply",
        //             noButtonText: "Cancel",
        //             functionOnNo: function() {
        //                 //alert('cancel');
        //             },
        //             functionOnOk: function(value) {
        //                     iconpositions.moveGridOnXaxis(Number(value));
        //             }
        //         });
        //     },
        //     functionOnOk: function() {
        //         jPopup({
        //             type: "input",
        //             message: "Enter a number to move grid. Use negative value to move up.<br><br>",
        //             yesButtonText: "Apply",
        //             noButtonText: "Cancel",
        //             functionOnNo: function() {
        //                 //alert('cancel');
        //             },
        //             functionOnOk: function(value) {
        //                     iconpositions.moveGridOnYaxis(Number(value));
        //             }
        //         });
        //     }
        // });
    },
    alignGrid:function(){
        jPopup({
            type: "input",
            message: "Enter a number for horizontal spacing between icons. <br><br> If you did not select the top left icon of the grid press cancel and do that. <br><br>",
            yesButtonText: "Apply",
            noButtonText: "Cancel",
            functionOnNo: function() {
                //alert('cancel');
            },
            functionOnOk: function(value) {
                jPopup({
                    type: "input",
                    message: "Enter a number for vertical spacing between icon rows.<br><br>",
                    yesButtonText: "Apply",
                    noButtonText: "Cancel",
                    functionOnNo: function() {
                        //alert('cancel');
                    },
                    functionOnOk: function(value2) {
                        iconpositions.alignGrid(Number(value), Number(value2));
                    }
                });
            }
        });
    },
    copyPage:function(){
        jPopup({
            type: "confirm",
            message: "Do you wish to copy icon locations from the first page?",
            yesButtonText: "Yes",
            noButtonText: "No",
            functionOnNo: function() {
                //sbMenu.toggleSubMenu(document.getElementById('alignOptionsMenu'));
            },
            functionOnOk: function() {
                iconpositions.copyFromPage();
            }
        });
    },
    cancelAlignMenu: function(){
        document.getElementById('alignOptionsMenu').style.display = 'none';
    },
    alignOptions: function(){
        sbMenu.toggleSubMenu(document.getElementById('drawerIconMenu'));
        document.getElementById('alignOptionsMenu').style.display = 'block';
    },
    showPosition: function(){
        iconpositions.spacingGrid();
    },
    resetIconPosition: function(){
        setTimeout(function(){
            iconpositions.resetIconPosition();
        },500);
    },
    removeIconFromSB: function (bundle){
        var i,
            e;

        for (e = 0; e < sb.iconInfo.length; e += 1) {
            if (sb.iconInfo[e].id === bundle) {
                sb.iconInfo.splice(e, 1);
            }
        }

        for (i = 0; i < sb.locations.length; i += 1) {
            if (sb.locations[i].id === bundle) {
                sb.locations.splice(i, 1);
            }
        }
        delete sb.changedIcons[bundle];
        sb.list.removeChild(document.getElementById(bundle));
        sb.saveCurrent();
        sb.deleteBundle = false;
    },
    changeIcon: function (bundle, goahead) {
        sb.changingIcon = bundle;
        if(bundle === "com.junesiphone.drawer" && !goahead){
            sb.changeDrawerIconWindow();
            sb.dragging = true;
            return;
        }else{
            sb.changeIconWindow();
        }
    },
    loadIcons: function () {
        var i, e, info, doc = document;
        if (localStorage.sbpositions) {
            sb.locations = JSON.parse(localStorage.getItem('sbpositions'));
        }
        if (localStorage.sbiconInfo) {
            sb.iconInfo = JSON.parse(localStorage.getItem('sbiconInfo'));
        }
        if (localStorage.sbchangedicons){
            sb.changedIcons = JSON.parse(localStorage.getItem('sbchangedicons'));
        }
        for (e = 0; e < sb.iconInfo.length; e += 1) {
            info = sb.iconInfo[e];
            this.replaceIcon(info.id, info.bundle, info.name, info.iconImage, e);
        }
        for (i = 0; i < sb.locations.length; i += 1) {
            try {
                doc.getElementById(sb.locations[i].id).style.top = sb.locations[i].top + "px";
                doc.getElementById(sb.locations[i].id).style.left = sb.locations[i].left + "px";
                if(sb.locations[i].opacity){
                    doc.getElementById(sb.locations[i].id).style.opacity = sb.locations[i].opacity;
                }
                if(sb.locations[i].scale){
                    doc.getElementById(sb.locations[i].id).style.webkitTransform = "scale(" + sb.locations[i].scale + ")";
                }
            } catch (err) {
                console.log("ERROR: " + sb.locations[i].id + " " + err);
            }
        }
    },
    setOverlayImage: function(img){
        overlay = false;
        localStorage.sbiconoverlay = img;
        sbMenu.addRule(document.styleSheets[0], ".iconImageView:after", "background-image:url('" + img + "')");
    },
    setUnderlayImage: function(img){
        underlay = false;
        localStorage.sbiconunderlay = img;
        sbMenu.addRule(document.styleSheets[0], ".iconImageView:before", "background-image:url('" + img + "')");
    },
    setBadgeImage: function(img){
        badgeimage = false;
        localStorage.sbbadgeimage = img;
        sbMenu.addRule(document.styleSheets[0], ".iconImageBadge", "background-image:url('" + img + "')");
    },
    //tap hold show menu top change icon, browser will appear
    changeAppIcon: function () {
        sbMenu.toggleSubMenu(document.getElementById('drawerIconMenu'));
        window.location = 'frontpage:loadIconBrowser';
    },
    changeApp: function () {
        sb.changingApp = true;
        sbMenu.toggleSubMenu(document.getElementById('drawerIconMenu'));
        Drawer.toggleDrawer({
            state: 'changingApp',
            callback: function(newApp) {
                sb.changingApp = false;
                sb.drawerCallbackForAppChange(newApp);
            }
        });
    },
    drawerCallbackForAppChange: function (app){
        //change 
        var left, top, scaleVal, opacityVal, appRef;
        for (var i = 0; i < sb.locations.length; i++) {
            if(sb.locations[i].id === sb.changingIcon){
                sb.locations[i].id = app;
                left = sb.locations[i].left;
                top = sb.locations[i].top;
            }
        }
        this.removeIconFromSB(sb.changingIcon);
        this.setIcon(app);
        scaleVal = sb.getInfoFromStorage(app, 'scale', '1.0');
        opacityVal = sb.getInfoFromStorage(app, 'opacity', '1.0');
        sb.removeDoubleLocation(app);
        sb.locations.push({
            id: app, 
            top: top, 
            left: left,
            opacity: opacityVal,
            scale: scaleVal
        });
        sb.saveInfo('sbpositions', sb.locations);
        appRef = document.getElementById(app);
        appRef.style.left = left + "px";
        appRef.style.top = top + "px";
        appRef.style.transform = "scale("+scaleVal+")";
        appRef.style.opacity = opacityVal;
    },
    getInfoFromStorage: function (app, value, def){
        var de;
        for (de = 0; de < sb.locations.length; de += 1) {
            if(sb.locations[de].id == app){
                if(sb.locations[de][value]){
                    return sb.locations[de][value];
                }
            }
        }
        return def;
    },
    moveIcon: function (value, position) {
        var app = document.getElementById(sb.changingIcon),
            scaleVal;
        if(position === "left"){
            app.style.left = value + "px";
        }else if (position === "top"){
            app.style.top = value + "px";
        }
        scaleVal = sb.getInfoFromStorage(sb.changingIcon, 'scale', '1.0');
        sb.removeDoubleLocation(sb.changingIcon);
        sb.locations.push({
            id: sb.changingIcon, 
            top: app.style.top.replace('px', ''), 
            left: app.style.left.replace('px', ''),
            opacity: app.style.opacity,
            scale: scaleVal
        });
        sb.saveInfo('sbpositions', sb.locations);
        if(iconpositions.showGrid){
            iconpositions.spacingGrid(true);
        }  
    },
    setAppScale: function(app, value){
        app.style.webkitTransform = "scale(" + value + ")";
        sb.removeDoubleLocation(app.id);
        sb.locations.push({
            id: app.id, 
            top: app.style.top.replace('px', ''), 
            left: app.style.left.replace('px', ''),
            opacity: app.style.opacity,
            scale: value
        });
        sb.saveInfo('sbpositions', sb.locations);
    },
    scaleIcon: function(value){
        jPopup({
            type: "confirm",
            message: "Apply to all icons or just one?",
            yesButtonText: "All",
            noButtonText: "One",
            functionOnNo: function() {
                sb.setAppScale(document.getElementById(sb.changingIcon), value);
            },
            functionOnOk: function() {
                var list = document.getElementById('list');
                for (var i = 0; i < list.children.length; i++) {
                    sb.setAppScale(list.children[i], value);
                } 
            }
        });
    },
    opacityIcon: function(value){
        var app = document.getElementById(sb.changingIcon),
            scaleVal;
        app.style.opacity = value;
        scaleVal = sb.getInfoFromStorage(sb.changingIcon, 'scale', '1.0');
        sb.removeDoubleLocation(sb.changingIcon);
        sb.locations.push({
            id: sb.changingIcon, 
            top: app.style.top.replace('px', ''), 
            left: app.style.left.replace('px', ''),
            opacity: value,
            scale: scaleVal
        });
        sb.saveInfo('sbpositions', sb.locations); 
    },
    pickBadgeImage: function() {
        badgeimage = true;
        window.location = 'frontpage:loadIconBrowser';
    },
    resetBadgeImage: function() {
        jPopup({
            type: "alert",
            message: "Badge image removed.",
            okButtonText: "OK"
        });
        localStorage.removeItem('sbbadgeimage');
        sbMenu.removeRule(document.styleSheets[0], ".iconImageBadge", "background-image");
    },
    hideBadgeNumber: function(){
        //localStorage.sbbadgenumber = "YES";
        //sbMenu.addRule(document.styleSheets[0], ".iconImageBadge", "width:16px!important; height:16px!important; padding:0!important;");
    },
    disableSnapping: function(){
        sbMenu.disableSnapping();
    },
    lockEverything: function(){
        sbMenu.toggleLock();
    },
    lockPaging: function(){
        sbMenu.togglePageLock();
    },
    widgetBG: function (){
        widgets.toggleBackground();
    },
    widgetDisable: function (){
        widgets.widgetDisable();
    },
    iconOverlay: function(){
        overlay = true;
        window.location = 'frontpage:loadIconBrowser';
    },
    iconUnderlay: function(){
        underlay = true;
        window.location = 'frontpage:loadIconBrowser';
    },
    resetOverlay: function(){
        localStorage.removeItem('sbiconoverlay');
        sbMenu.removeRule(document.styleSheets[0], ".iconImageView::after", "background-image");
    },
    resetUnderlay: function(){
        localStorage.removeItem('sbiconunderlay');
        sbMenu.removeRule(document.styleSheets[0], ".iconImageView::before", "background-image");
    },
    hideLabels: function(){
        sbMenu.hideLabels();
    },
    hideBadges: function(){
        sbMenu.hideBadges();
    },
    hidePageDots: function(){
        PageDots.hidePageDots();
    },
    showSignal: function(){
        Statusbar.showSignal();
    },
    showWifi: function(){
        Statusbar.showWifi();
    },
    showBattery: function(){
        Statusbar.showBattery();
    },
    showGrid: function(){
        var grid = document.getElementById('grid');
        if(grid.style.display === "none"){
            grid.style.display = "block";
        }else{
            grid.style.display = "none";
        }
    },
    saveLayout: function(){
        sblayouts.saveLayout();
    },
    deleteLayouts: function(){
        sblayouts.deleteLayout();
    },
    uploadLayout: function(){
        uploader.showFrame();
    },
    downloadLayout: function(){
        uploader.showViewFrame();
    },
    clearfolderInfo: function(){
        jPopup({
            type: "confirm",
            message: "Would you like to clear all folder info? <br><br> This will erase all icons in all folders, but will not delete the folder.",
            yesButtonText: "Yes",
            noButtonText: "No",
            functionOnNo: function() {
            },
            functionOnOk: function() {
                folders.clearInfo();
            }
        });
    },
    clearfolderOptions: function(){
        folders.clearOptions();
    },
    cleardrawerOptions: function(){
        drawerOptions.clearOptions();
    },
    resizeBadgeOptions: function(){
        document.getElementById('resizeBadgeOptions').style.display = "block";
        document.getElementById('badgeOptionsMenu').style.display = "none";
        document.getElementById('menu').style.display = "none";
    },
    setMoveBadgeOptions: function(){
        document.getElementById('badgeOptionsMenu').style.display = "none";
        (function(){
            var scale = "1.0",
                xInput = document.getElementById('badgeXaxisInput'),
                yInput = document.getElementById('badgeYaxisInput'),
                elements = document.querySelectorAll(".iconImageBadge");
                function updateElements(left, top){
                    for(var i = 0; i < elements.length; i++){
                        if(localStorage.sizebadgeoptions){
                            scale = localStorage.sizebadgeoptions.split('~')[2];
                        }
                        elements[i].style.webkitTransform = "scale(" + scale + ")translate("+left+"px, "+top+"px)";
                    }  
                    xInput.value = left;
                    yInput.value = top;
                }
            dragAdjuster.init({
                color:"black",
                drag: function(ev, ui){
                    ui.position.left = Math.round(ui.position.left);
                    ui.position.top = Math.round(ui.position.top);
                    updateElements(ui.position.left, ui.position.top);
                },
                stop:function(ev, ui){
                    ui.position.left = Math.round(ui.position.left);
                    ui.position.top = Math.round(ui.position.top);
                    var x, y, scale, store;
                    x = ui.position.left;
                    y = ui.position.top;
                    if(localStorage.sizebadgeoptions){
                        scale = localStorage.sizebadgeoptions.split('~')[2];
                    }
                    if(!x){
                        x = 0;
                    }
                    if(!y){
                        y = 0;
                    }
                    if(!scale){
                        scale = 1.0;
                    }
                    store = x + "~" + y + "~" + scale;
                    localStorage.sizebadgeoptions = store;
                    sbMenu.addRule(document.styleSheets[0], ".iconImageBadge", "-webkit-transform:scale(" + scale + ")translate(" + x + "px," + y + "px);!important");
                }
            });
        }());
    },
    setSizeBadgeOptions: function(){
        var x, y, scale, store;
        x = document.getElementById('badgeXaxisInput').value;
        y = document.getElementById('badgeYaxisInput').value;
        scale = document.getElementById('badgeScaleInput').value;
        if(!x){
            x = 0;
        }
        if(!y){
            y = 0;
        }
        if(!scale){
            scale = 1.0;
        }
        store = x + "~" + y + "~" + scale;
        localStorage.sizebadgeoptions = store;
        sbMenu.addRule(document.styleSheets[0], ".iconImageBadge", "-webkit-transform:scale(" + scale + ")translate(" + x + "px," + y + "px);!important");
        jPopup({
            type: "alert",
            message: "Badge size and position updated!",
            okButtonText: "OK"
        });

        window.scrollTo(0,0);
    },
    resetSizeBadgeOptions: function(){
        localStorage.removeItem('sizebadgeoptions');
        sbMenu.removeRule(document.styleSheets[0], ".iconImageBadge", "transform");
        jPopup({
            type: "alert",
            message: "Badge size and position reset!",
            okButtonText: "OK"
        });
    },
    loadSaved: function(){
        
      if(localStorage.sbhidelabels){
        sbMenu.hideLabels();
      }else{
        sbMenu.removeRule(document.styleSheets[0], ".iconImageLabel", "opacity");
      }

      if(localStorage.sbhidebadges){
        sbMenu.hideBadges();
      }else{
        sbMenu.removeRule(document.styleSheets[0], ".iconImageBadge", "opacity");
      }

      // var dSN = document.getElementById('disableSnapping');
      // if(localStorage.sbnosnap){
      //   dSN.innerHTML = "Enable Snapping";
      // }else{
      //   dSN.innerHTML = "Disable Snapping";
      // }

      var lev = document.getElementById('lockEverything');
      if(localStorage.sblock){
        widgets.setWidgetDisableMove("add");
        document.getElementById('list').classList.add('canceledIcons');
        lev.innerHTML = "Unlock Items";
      }else{
         document.getElementById('list').classList.remove('canceledIcons');
         lev.innerHTML = "Lock Items";
         widgets.setWidgetDisableMove("remove");
      }

      var dLP = document.getElementById('lockPaging');
      if(localStorage.sblockpaging){
        lockpages = true;
        dLP.innerHTML = "Unlock Paging";
        document.getElementById('container').classList.add('canceled');
      }else{
        lockpages = false;
        dLP.innerHTML = "Lock Paging";
        document.getElementById('container').classList.remove('canceled');
      }


      if(localStorage.sbiconsize){
        sbMenu.setIconSize(localStorage.sbiconsize);
        doc.getElementById('iconInput').value = localStorage.sbiconsize;
      }else{
        sbMenu.removeRule(document.styleSheets[0], ".iconImageView", "width");
        sbMenu.removeRule(document.styleSheets[0], ".iconView", "width");
        sbMenu.removeRule(document.styleSheets[0], ".iconImageView", "height");
        sbMenu.removeRule(document.styleSheets[0], ".iconView", "height");
        sbMenu.removeRule(document.styleSheets[0], ".iconImageLabel", "width");
        sbMenu.removeRule(document.styleSheets[0], ".iconViewDragging::before", "margin-top");
        sbMenu.removeRule(document.styleSheets[0], ".iconImageBadge", "height");
        sbMenu.removeRule(document.styleSheets[0], ".iconImageBadge", "line-height");
        sbMenu.removeRule(document.styleSheets[0], ".iconImageBadge", "padding");
        sbMenu.removeRule(document.styleSheets[0], ".iconImageBadge", "font-size");
      }

      if(localStorage.sizebadgeoptions){
        var scale, x, y, 
        sp = localStorage.sizebadgeoptions.split('~');
        x = sp[0];
        y = sp[1];
        scale = sp[2];

        sbMenu.addRule(document.styleSheets[0], ".iconImageBadge", "-webkit-transform:scale(" + scale + ")translate(" + x + "px," + y + "px);!important");
      }else{
        sbMenu.removeRule(document.styleSheets[0], ".iconImageBadge", "transform");
      }

      if(localStorage.sbbadgecolor){
        sbMenu.setBadgeColor(localStorage.sbbadgecolor);
        doc.getElementById('badgeColorInput').value = localStorage.sbbadgecolor;
      }else{
        sbMenu.removeRule(document.styleSheets[0], ".iconImageBadge", "background-color");
      }

      if(localStorage.sbbadgebordercolor){
        sbMenu.setBadgeBorderColor(localStorage.sbbadgebordercolor);
        doc.getElementById('badgeBorderColorInput').value = localStorage.sbbadgebordercolor;
      }else{
        sbMenu.removeRule(document.styleSheets[0], ".iconImageBadge", "border");
      }

      if(localStorage.sbbadgetextcolor){
        sbMenu.setBadgeTextColor(localStorage.sbbadgetextcolor);
        doc.getElementById('badgeTextColorInput').value = localStorage.sbbadgetextcolor;
      }else{
        sbMenu.removeRule(document.styleSheets[0], ".iconImageBadge", "color");
      }

      if(localStorage.sbiconradius){
        sbMenu.setIconRadius(localStorage.sbiconradius);
        doc.getElementById('iconRadius').value = localStorage.sbiconradius;
      }else{
        sbMenu.removeRule(document.styleSheets[0], ".iconImageView", "border-radius");
      }

      if(localStorage.sbiconoverlay){
        sb.setOverlayImage(localStorage.sbiconoverlay);
      }else{
        sbMenu.removeRule(document.styleSheets[0], ".iconImageView::after", "background-image");
      }

      if(localStorage.sbiconunderlay){
        sb.setUnderlayImage(localStorage.sbiconunderlay);
      }else{
        sbMenu.removeRule(document.styleSheets[0], ".iconImageView::before", "background-image");
      }

      if(localStorage.sbbadgeimage){
        sb.setBadgeImage(localStorage.sbbadgeimage);
      }else{
        sbMenu.removeRule(document.styleSheets[0], ".iconImageBadge", "background-image");
      }

      if(localStorage.sblabelcolor){
        sbMenu.setLabelColor(localStorage.sblabelcolor);
      }else{
        sbMenu.removeRule(document.styleSheets[0], ".iconImageLabel", "color");
      }

      Statusbar.reload();

    },
    reload: function(){
        document.getElementById('list').innerHTML = "";
        for (var ie = 0; ie < document.styleSheets[0].cssRules.length; ie++) {
            document.styleSheets[0].deleteRule(document.styleSheets[0].cssRules[ie]);
        }
        for (var ie2 = 0; ie2 < document.styleSheets[0].cssRules.length; ie2++) {
            document.styleSheets[0].deleteRule(document.styleSheets[0].cssRules[ie2]);
        }
        sb.locations = [];
        sb.iconInfo = [];
        sb.deleteBundle = false;
        sb.changingIcon = "";
        sb.changedIcons = {};
        sbMenu.labelsHidden = false;
        sbMenu.badgesHidden = false;
        sblayouts.ayoutObjects = [];
        sb.loadSaved();
        sb.loadIcons();
        Statusbar.reload();
        PageDots.reload();
        widgets.reload();
    }
};

sb.loadSaved();

//localStorage.removeItem('sbiconInfo');
//localStorage.removeItem('sbpositions');





