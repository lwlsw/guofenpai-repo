#!/bin/bash
iofbres r