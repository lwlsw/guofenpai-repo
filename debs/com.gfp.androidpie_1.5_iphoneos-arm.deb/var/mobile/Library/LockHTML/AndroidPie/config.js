var TextColor = 'Black';
var DarkIcon = true;
var TwentyFourHour = false;
var CustomText = "Johns Pixel 3";
var CustomTextSize = 25;
var ZoomLevel = 1;
