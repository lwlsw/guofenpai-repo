var TextColor = 'Black';
var DarkIcon = true;
var TwentyFourHour = false;
var ZoomLevel = 1;
