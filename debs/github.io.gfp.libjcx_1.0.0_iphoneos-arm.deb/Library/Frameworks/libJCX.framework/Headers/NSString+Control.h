#import <Foundation/Foundation.h>

@interface NSString (Control)
- (NSString *_Nonnull)stringByInterpolatingPackageInfoFromControl:(NSDictionary *_Nullable)control;
@end
