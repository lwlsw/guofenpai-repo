var FontSize = 72; // In pixels
var TopPadding = 200; // In pixels
var TwelveHour = true;
var TextColor = "ffffff"; // Hex code
var Opacity = 1.0; // 0.0 - 1.0
