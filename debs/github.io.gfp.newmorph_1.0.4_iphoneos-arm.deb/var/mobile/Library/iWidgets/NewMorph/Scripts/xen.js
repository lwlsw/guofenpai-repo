
//--------------------------- XENINFO ---------------------------
function mainUpdate(type){ 
	if(type === "weather"){
		checkWeather();
	}else if (type === "battery"){
		updateBattery();	  	
	}else if (type === "music"){
		if(mu === 1)
			checkMusic();
	}
}


//------------------------- WEATHER FUNCTIONS ---------------------------
function checkWeather(){
	document.getElementById('weatherIcon').src = 'weather_icons/' + weather.conditionCode + '.png';
	if(one === 1){
		document.getElementById('weatherIconMus').src = 'weather_icons/' + weather.conditionCode + '.png';
	}
	
	document.getElementById('condition').innerHTML = weather.condition;
	
	document.getElementById('tempe').innerHTML = weather.temperature + 'º';
	
	
}


//------------------------- BATTERY FUNCTIONS ---------------------------
//var batteryPercent = 100;
//var batteryCharging = 0;
//updateBattery();
//var isCharging = false;

function updateBattery() {
	"use strict";

	document.getElementById("percent").innerHTML = 'Battery level: ' + batteryPercent + '%';
	
	document.getElementById("bl2").style.width = batteryPercent + '%';
	
}

