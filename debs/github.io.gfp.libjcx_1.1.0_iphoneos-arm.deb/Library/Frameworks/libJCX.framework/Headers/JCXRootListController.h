#import <Preferences/PSListController.h>
#import <Preferences/PSSpecifier.h>
#import <NSTask.h>
#import "JCXPackageInfo.h"

@interface JCXRootListController : PSListController
@end
